#ifndef _IPTABLES_MULTI_H
#define _IPTABLES_MULTI_H 1

extern int iptables_main(int, char **);
extern int iptables_save_main(int, char **);
extern int iptables_restore_main(int, char **);

#endif /* _IPTABLES_MULTI_H */
