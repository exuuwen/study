ovs-ofctl add-flows manbr - << EOF
 cookie=0x0, duration=122.108s, table=0, n_packets=15692, n_bytes=3216835,  priority=0 actions=NORMAL
EOF
