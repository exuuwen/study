ovs-ofctl add-flows manbr - << EOF
 cookie=0x0, duration=176.299s, table=0, n_packets=6, n_bytes=2076,  priority=30000,in_port=1,dl_type=0x88cc actions=LOCAL
 cookie=0x0, duration=176.299s, table=0, n_packets=10, n_bytes=600,  priority=30000,in_port=LOCAL,dl_type=0x88cc actions=output:1
 cookie=0x0, duration=176.299s, table=0, n_packets=38925, n_bytes=3247124,  priority=0 actions=NORMAL
EOF
