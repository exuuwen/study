ovs-ofctl add-flows br0 - << EOF
 cookie=0x0, duration=176.295s, table=0, n_packets=0, n_bytes=0,  priority=60040,arp,dl_dst=fa:ff:ff:ff:ff:ff,arp_tpa=10.9.0.1 actions=move:NXM_OF_ETH_SRC[]->NXM_OF_ETH_DST[],mod_dl_src:fa:ff:ff:ff:ff:ff,load:0x2->NXM_OF_ARP_OP[],move:NXM_NX_ARP_SHA[]->NXM_NX_ARP_THA[],move:NXM_OF_ARP_SPA[]->NXM_OF_ARP_TPA[],load:0xfaffffffffff->NXM_NX_ARP_SHA[],load:0xa090001->NXM_OF_ARP_SPA[],IN_PORT
 cookie=0x0, duration=176.295s, table=0, n_packets=0, n_bytes=0,  priority=60040,arp,dl_dst=ff:ff:ff:ff:ff:ff,arp_tpa=10.9.0.1 actions=move:NXM_OF_ETH_SRC[]->NXM_OF_ETH_DST[],mod_dl_src:fa:ff:ff:ff:ff:ff,load:0x2->NXM_OF_ARP_OP[],move:NXM_NX_ARP_SHA[]->NXM_NX_ARP_THA[],move:NXM_OF_ARP_SPA[]->NXM_OF_ARP_TPA[],load:0xfaffffffffff->NXM_NX_ARP_SHA[],load:0xa090001->NXM_OF_ARP_SPA[],IN_PORT
 cookie=0x0, duration=176.298s, table=0, n_packets=0, n_bytes=0,  priority=60010,ip,dl_dst=fa:ff:ff:ff:ff:ff,nw_dst=10.19.0.0/16 actions=CONTROLLER:65535
 cookie=0x0, duration=176.297s, table=0, n_packets=0, n_bytes=0,  priority=60010,ip,dl_dst=fa:ff:ff:ff:ff:ff,nw_dst=10.10.0.0/16 actions=CONTROLLER:65535
 cookie=0x0, duration=176.297s, table=0, n_packets=0, n_bytes=0,  priority=60010,ip,dl_dst=fa:ff:ff:ff:ff:ff,nw_dst=10.8.0.0/16 actions=CONTROLLER:65535
 cookie=0x0, duration=176.297s, table=0, n_packets=0, n_bytes=0,  priority=60010,ip,dl_dst=fa:ff:ff:ff:ff:ff,nw_dst=10.13.0.0/16 actions=CONTROLLER:65535
 cookie=0x0, duration=176.296s, table=0, n_packets=0, n_bytes=0,  priority=60010,ip,dl_dst=fa:ff:ff:ff:ff:ff,nw_dst=10.200.0.0/16 actions=CONTROLLER:65535
 cookie=0x0, duration=176.296s, table=0, n_packets=0, n_bytes=0,  priority=60010,ip,dl_dst=fa:ff:ff:ff:ff:ff,nw_dst=10.6.0.0/16 actions=CONTROLLER:65535
 cookie=0x0, duration=176.295s, table=0, n_packets=0, n_bytes=0,  priority=60010,arp,dl_dst=ff:ff:ff:ff:ff:ff actions=CONTROLLER:65535
 cookie=0x0, duration=0.016s, table=0, n_packets=6, n_bytes=360,  priority=0 actions=CONTROLLER:65535
EOF
