ovs-ofctl add-flows wanbr - << EOF
 cookie=0x0, duration=176.303s, table=0, n_packets=6, n_bytes=360,  priority=0 actions=NORMAL
EOF
