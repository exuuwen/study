#ifndef ZIJIN_RDMA_DEV_H
#define ZIJIN_RDMA_DEV_H

#define COMMOND_QUEUE_SIZE_LOG  5   
#define COMMOND_ENTRY_SIZE_LOG  6   

struct zijin_cmd_layout {
        uint8_t         type;
        uint8_t         rsvd0[3];
        __be32          inlen;
        __be64          in_ptr;
        __be32          in[4];
        __be32          out[4];
        __be64          out_ptr;
        __be32          outlen;
        uint8_t         token;
        uint8_t         sig; 
        uint8_t         rsvd1;
        uint8_t         status_own;
};

union zijin_command_queue {
    uint64_t     val;
    struct {
        uint32_t phy_addr_h32;
        uint16_t phy_addr_l16;
        uint8_t  phy_addr_l4:4,
	         reserve:1,
	         nic_interface:3;
        uint8_t  log_cmdq_size:4,
	         log_cmdq_stride:4;
    } cq;
};
#endif /*ZIJIN_RDMA_DEV_H*/
