#include "qemu/osdep.h"
#include <zlib.h>

#include "hw/pci/pci.h"
#include "hw/qdev-properties.h"
#include "migration/vmstate.h"
#include "sysemu/dma.h"
#include "qemu/error-report.h"
#include "qemu/module.h"
#include "qemu/timer.h"
#include "net/net.h"
#include "net/eth.h"
#include "sysemu/sysemu.h"
#include "qom/object.h"
#include <linux/types.h>

#include "dev.h"

#define TYPE_ZIJIN_RDMA "zijin-rdma"
#define ZIJIN_RDMA_PCI_REVID 0x10

OBJECT_DECLARE_SIMPLE_TYPE(ZijinRdmaState, ZIJIN_RDMA)

struct ZijinRdmaState {
    /*< private >*/
    PCIDevice parent_obj;
    /*< public >*/

    MemoryRegion bar_mem;

    uint32_t command_doorbell_vector;
    union zijin_command_queue cmdq;

    struct zijin_cmd_layout *lays;
    dma_addr_t  ring_dma_addr;

    uint64_t unused;
};

static void zijin_rdma_reset(DeviceState *d)
{
/*
    ZijinRdmaState *s = ZIJIN_RDMA(d);
**/
}

static const VMStateDescription vmstate_zijin_rdma = {
    .name = "ziji_rdma",
    .version_id = 1,
    .minimum_version_id = 1,
    .post_load = NULL,
    .pre_save  = NULL,
    .fields = (VMStateField[]) {
        VMSTATE_UINT64_V(unused, ZijinRdmaState, 0),
        VMSTATE_END_OF_LIST()
    },
};

typedef int (*zijin_command)(ZijinRdmaState *s, struct zijin_cmd_layout *lay);

struct zijin_rdma_command {
    zijin_command cb;
};

static int test_command(ZijinRdmaState *s, struct zijin_cmd_layout *lay)
{
    printf("test command lay type %d\n", lay->type);
    return 0;
}

struct zijin_rdma_command commands[255];

static int zijin_rdma_reg_command(uint8_t type, zijin_command cb)
{
    if (commands[type].cb != NULL) {
        printf("zijin_rdma_run_command type %u cb exist\n", type);
        return -1;
    }

    commands[type].cb = cb;

    return 0;
}

static int zijin_rdma_run_command(ZijinRdmaState *s, struct zijin_cmd_layout *lay)
{
    if (!lay) {
        printf("zijin_rdma_run_command no lay\n");
        return -1;
    }

    if (!commands[lay->type].cb) {
        printf("zijin_rdma_run_command no %u cb\n", lay->type);
        return -1;
    }

    return (*commands[lay->type].cb)(s, lay);
}

static uint64_t command_queue_doorbell_read(ZijinRdmaState *s, hwaddr addr, unsigned size)
{
    printf("command_queue_doorbell_read unsupported\n");
    return 0;
}

static void command_queue_doorbell_write(ZijinRdmaState *s, hwaddr addr, uint64_t val, unsigned size)
{
    if (size == 4) {
        int i;

        uint32_t command_doorbell_vector = val;

        for (i = 0; i<32; i++) {
            struct zijin_cmd_layout lay;
        
            if ((command_doorbell_vector >> i) % 2) {

                dma_addr_t dma_addr = s->ring_dma_addr + (i * sizeof(struct zijin_cmd_layout));

                pci_dma_read(PCI_DEVICE(s), dma_addr, &lay, sizeof(struct zijin_cmd_layout));
                printf("doorbeel vector 0x%x, dma addr 0x%lx, type 0x%x\n", command_doorbell_vector, dma_addr, lay.type);
                zijin_rdma_run_command(s, &lay);
                printf("ahhaha pinline %u...\n", PCI_DEVICE(s)->config[PCI_INTERRUPT_LINE]);
                //pci_set_irq(PCI_DEVICE(s), 1);
                //pci_set_irq(PCI_DEVICE(s), 0);
            }
        }

        printf("command_queue_doorbell_write 0x%x\n", command_doorbell_vector);

        return;
    }
        
    printf("command_queue_doorbell_write 0x%lx with invalid size %u\n", addr, size);
}

static uint64_t command_queue_reg_read(ZijinRdmaState *s, hwaddr addr, unsigned size)
{
    if (size == 8) {
        printf("command_queue_reg_read 0x%lx\n", s->cmdq.val);
        return s->cmdq.val;
    }

    printf("command_queue_reg_read 0x%lx with invalid size %u\n", addr, size);
    return 0;
}

static void command_queue_reg_write(ZijinRdmaState *s, hwaddr addr, uint64_t val, unsigned size)
{
    if (size == 8) {
        union zijin_command_queue cmdq_tmp;

        cmdq_tmp.val = val;
        if (cmdq_tmp.cq.log_cmdq_size != COMMOND_QUEUE_SIZE_LOG ||
            cmdq_tmp.cq.log_cmdq_stride != COMMOND_ENTRY_SIZE_LOG) {
            printf("command_queue_reg_write can't write cmdq_size or cmdq_stride\n");
            return;
        }

        s->cmdq.val = val;
        s->ring_dma_addr = ((uint64_t)s->cmdq.cq.phy_addr_h32 << 32) |
                           ((uint32_t)s->cmdq.cq.phy_addr_l16 << 16) | 
                           ((uint16_t)s->cmdq.cq.phy_addr_l4 << 12); 

        printf("command_queue_reg_write 0x%lx, dma addr 0x%lx\n", s->cmdq.val, s->ring_dma_addr);
        return;
    }

    printf("command_queue_reg_write 0x%lx with invalid size %u\n", addr, size);
}

static struct zijin_rdma_io_ops_by_range {
    hwaddr start;
    hwaddr end;
    uint64_t (*read)(ZijinRdmaState *s, hwaddr offset, unsigned size);
    void (*write)(ZijinRdmaState *s, hwaddr offset, uint64_t val, unsigned size);
} ops_by_range[] = {
    {0x10, 0x18, command_queue_reg_read, command_queue_reg_write},
    {0x18, 0x1c, command_queue_doorbell_read, command_queue_doorbell_write},
};

static void zijin_rdma_io_write(void *opaque, hwaddr addr,
                                uint64_t val, unsigned size)
{
    ZijinRdmaState *s = opaque;

    for (int idx = 0; idx < ARRAY_SIZE(ops_by_range); idx++) {
        if (addr >= ops_by_range[idx].start &&
            addr < ops_by_range[idx].end &&
            (ops_by_range[idx].write != NULL)) {
            ops_by_range[idx].write(s, addr - ops_by_range[idx].start, val, size);
        }
    }
}

static uint64_t zijin_rdma_io_read(void *opaque, hwaddr addr,
                                   unsigned size)
{
    ZijinRdmaState *s = opaque;

    for (int idx = 0; idx < ARRAY_SIZE(ops_by_range); idx++) {
        if (addr >= ops_by_range[idx].start &&
            addr < ops_by_range[idx].end &&
            (ops_by_range[idx].read != NULL)) {
            return ops_by_range[idx].read(s, addr - ops_by_range[idx].start, size);
        }
    }

    return -1;
}

static const MemoryRegionOps zijin_rdma_io_ops = {
    .read = zijin_rdma_io_read,
    .write = zijin_rdma_io_write,
    .valid = {
        .min_access_size = 4,
        .max_access_size = 8,
    },
    .impl = {
        .min_access_size = 4,
        .max_access_size = 8,
    },
    .endianness = DEVICE_LITTLE_ENDIAN,
};

static void pci_zijin_rdma_uninit(PCIDevice *dev)
{
/*
    ZijinRdmaState *s = ZIJIN_RDMA(dev);
**/
}

static void pci_zijin_rdma_realize(PCIDevice *dev, Error **errp)
{
    ZijinRdmaState *s = ZIJIN_RDMA(dev);
    uint8_t *pci_conf;

    pci_conf = dev->config;
    pci_conf[PCI_INTERRUPT_PIN] = 1;    /* interrupt pin A */
    /* TODO: start of capability list, but no capability */
    pci_conf[PCI_CAPABILITY_LIST] = 0;

    s->cmdq.cq.log_cmdq_size = COMMOND_QUEUE_SIZE_LOG,
    s->cmdq.cq.log_cmdq_stride = COMMOND_ENTRY_SIZE_LOG,
    s->command_doorbell_vector = 0;
    s->ring_dma_addr = 0;
    s->lays = NULL;

    memory_region_init_io(&s->bar_mem, OBJECT(s), &zijin_rdma_io_ops, s,
                          "zijin-rdma-mem", 0x100);
    pci_register_bar(dev, 0, PCI_BASE_ADDRESS_SPACE_MEMORY, &s->bar_mem);

    zijin_rdma_reg_command(1, test_command);
}

static void zijin_rdma_instance_init(Object *obj)
{
/*
    ZijinRdmaState *s = ZIJIN_RDMA(obj);
**/
}

static Property zijin_rdma_properties[] = {
    DEFINE_PROP_UINT64("unused", ZijinRdmaState, unused, 0),
    DEFINE_PROP_END_OF_LIST(),
};

static void zijin_rdma_class_init(ObjectClass *klass, void *data)
{
    DeviceClass *dc = DEVICE_CLASS(klass);
    PCIDeviceClass *k = PCI_DEVICE_CLASS(klass);

    k->realize = pci_zijin_rdma_realize;
    k->exit = pci_zijin_rdma_uninit;
    k->vendor_id = PCI_VENDOR_ID_ZIJIN_RDMA;
    k->device_id = PCI_DEVICE_ID_ZIJIN_RDMA;
    k->revision = ZIJIN_RDMA_PCI_REVID;
    k->class_id = PCI_CLASS_NETWORK_ETHERNET;
    dc->reset = zijin_rdma_reset;
    dc->vmsd = &vmstate_zijin_rdma;
    device_class_set_props(dc, zijin_rdma_properties);
    set_bit(DEVICE_CATEGORY_NETWORK, dc->categories);
}

static const TypeInfo zijin_rdma_info = {
    .name          = TYPE_ZIJIN_RDMA,
    .parent        = TYPE_PCI_DEVICE,
    .instance_size = sizeof(ZijinRdmaState),
    .class_init    = zijin_rdma_class_init,
    .instance_init = zijin_rdma_instance_init,
    .interfaces = (InterfaceInfo[]) {
        { INTERFACE_CONVENTIONAL_PCI_DEVICE },
        { },
    },
};

static void zijin_rdma_register_types(void)
{
    type_register_static(&zijin_rdma_info);
}

type_init(zijin_rdma_register_types)
