#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kernel.h>
#include <linux/compiler.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/pci.h>
#include <linux/dma-mapping.h>
#include <linux/delay.h>
#include <linux/ethtool.h>
#include <linux/gfp.h>
#include <linux/mii.h>
#include <linux/if_vlan.h>
#include <linux/crc32.h>
#include <linux/in.h>
#include <linux/ip.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <linux/cache.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <linux/uaccess.h>

#include "dev.h"

#define VERSION_STRING  "0.1"
#define DRIVER_AUTHOR   "chinatelecom"
#define DRV_NAME        "zijin_rdma"

#define PCI_VENDOR_ID_ZIJIN_RDMA 0x2022
#define PCI_DEVICE_ID_ZIJIN_RDMA 0x1230
#define ZIJIN_RDMA_PCI_REVID 0x10

struct zijin_rdma {
    struct zijin_cmd_layout *lays;
    dma_addr_t  ring_dma;
};

static struct zijin_rdma rdma_device;

static irqreturn_t zijin_interrupt (int irq, void *dev_instance)
{
    printk("in th zijin irq %d...\n", irq);
    return 0;
}

static int zijin_rdma_probe (struct pci_dev *pdev, const struct pci_device_id *ent)
{
    union zijin_command_queue cmdq;
    void __iomem *regs;
    size_t size;
    void *mem;
    int ret;

    pr_info_once("zijin_rdma init irq %d\n", pdev->irq);

    if (pdev->revision != ZIJIN_RDMA_PCI_REVID) {
        dev_info(&pdev->dev, "zijin_rdma reversion id != 0x10\n");
        return -ENODEV;
    }

    ret = pci_enable_device(pdev);
    if (ret) {
        dev_err(&pdev->dev, "can not enable \n");
        return -EIO;
    }
    pr_info_once("zijin_rdma enabled irq is %d\n", pdev->irq);

    ret = pci_request_regions(pdev, DRV_NAME);
    if (ret) {
        dev_err(&pdev->dev, "can not request regions \n");
        return -EIO;
    }

    if ((sizeof(dma_addr_t) > 4) &&
        !pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64)) &&
        !pci_set_dma_mask(pdev, DMA_BIT_MASK(64))) {
         dev_info(&pdev->dev, "dma set success\n");
    }

    regs = pci_iomap(pdev, 0, pci_resource_len(pdev, 0));
    if (!regs) {
        dev_err(&pdev->dev, "no MMIO resource\n");
        return -EIO;
    }

    pci_set_master(pdev);

    dev_info(&pdev->dev, "zijin device irq %d...\n", pdev->irq);
    if (pdev->irq) {
	ret = request_irq(pdev->irq, zijin_interrupt, IRQF_SHARED, "zijin_edma", pdev);
        if (!ret)
            dev_info(&pdev->dev, "zijin device irq %d success..\n", pdev->irq);
        else 
            dev_info(&pdev->dev, "zijin device irq %d fail %d..\n", pdev->irq, ret);
    }

    cmdq.val = *(((uint64_t *)regs) + 2);

    size = sizeof(struct zijin_cmd_layout) * (1 << cmdq.cq.log_cmdq_size);
    dev_info(&pdev->dev, "zijin_rdma read register cmdq = 0x%llx, qsize %lu\n", cmdq.val, size);
    
    if (cmdq.cq.log_cmdq_size != COMMOND_QUEUE_SIZE_LOG ||
        cmdq.cq.log_cmdq_stride != COMMOND_ENTRY_SIZE_LOG)
        return -1;

    mem = dma_alloc_coherent(&pdev->dev, sizeof(struct zijin_cmd_layout)*size,
                             &rdma_device.ring_dma, GFP_KERNEL);

    rdma_device.lays = mem;
    
    dev_info(&pdev->dev, "zijin_rdma ring dma 0x%llx\n", rdma_device.ring_dma);

    cmdq.cq.log_cmdq_stride = COMMOND_ENTRY_SIZE_LOG;
    cmdq.cq.log_cmdq_size = COMMOND_QUEUE_SIZE_LOG;
    cmdq.cq.phy_addr_h32 = (rdma_device.ring_dma >> 32) & 0xffffffff;
    cmdq.cq.phy_addr_l16 = (rdma_device.ring_dma & 0xffffffff) >> 16;
    cmdq.cq.phy_addr_l4 = (rdma_device.ring_dma & 0xffff) >> 12;
    cmdq.cq.reserve = 0;
    cmdq.cq.nic_interface = 0;

    *(((uint64_t *)regs) + 2) = cmdq.val;
    
    dev_info(&pdev->dev, "zijin_rdma read register doorbeel = 0x%x\n", *(((uint32_t *)regs) + 6));

    rdma_device.lays[0].type = 1;
    dev_info(&pdev->dev, "zijin_rdma ring data 0x%u\n", rdma_device.lays[0].type);
    *(((uint32_t *)regs) + 6) = 0x1;

    return 0;
}

static void zijin_rdma_remove_one (struct pci_dev *pdev)
{
    pr_info_once("zijin_rdma exit");
}

#ifdef CONFIG_PM
static int zijin_rdma_suspend (struct pci_dev *pdev, pm_message_t state)
{
    return 0;
}

static int zijin_rdma_resume (struct pci_dev *pdev)
{
    return 0;
}
#endif /* CONFIG_PM */

static const struct pci_device_id zijin_rdma_pci_tbl[] = {
    { PCI_DEVICE(PCI_VENDOR_ID_ZIJIN_RDMA, PCI_DEVICE_ID_ZIJIN_RDMA), },
    { },
};
MODULE_DEVICE_TABLE(pci, zijin_rdma_pci_tbl);

static struct pci_driver zijin_rdma_driver = {
	.name         = "zijin_rdma",
	.id_table     = zijin_rdma_pci_tbl,
	.probe        = zijin_rdma_probe,
	.remove       = zijin_rdma_remove_one,
#ifdef CONFIG_PM
	.resume       = zijin_rdma_resume,
	.suspend      = zijin_rdma_suspend,
#endif
};

module_pci_driver(zijin_rdma_driver);

MODULE_LICENSE("GPL v2");
MODULE_INFO(supported, "Test driver that simulate serial port over PCI");
MODULE_VERSION(VERSION_STRING);
MODULE_AUTHOR(DRIVER_AUTHOR);
