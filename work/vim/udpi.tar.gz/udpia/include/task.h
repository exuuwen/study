#ifndef _UDPI_TASK_H_
#define _UDPI_TASK_H_

void udpi_task_iplist(void);
void udpi_task_complist(void);

#endif
