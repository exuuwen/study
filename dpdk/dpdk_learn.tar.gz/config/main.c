#include <stdio.h>
#include <assert.h>
#include "rte_cfgfile.h"


int main(int argc, char* argv[])
{
	struct rte_cfgfile *file;
	char *file_name = "test.cfg";
	unsigned int n_cores;

	file = rte_cfgfile_load(file_name, 0);
	assert(file != NULL);

	n_cores = (unsigned int) rte_cfgfile_num_sections(file, "core", strnlen("core", 5));
	printf("n_cores:%u\n", n_cores);

	if (rte_cfgfile_has_section(file, "wx"))
	{
		printf("has section 'wx'\n");

		if (rte_cfgfile_has_entry(file, "wx", "age"))
		{
			printf("section 'wx' has entry 'age'\n");
			printf("wx age is %s\n", rte_cfgfile_get_entry(file, "wx", "age"));
		}
	}	

	return 0;
	
}
