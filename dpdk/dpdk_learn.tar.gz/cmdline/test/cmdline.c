#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <inttypes.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <netinet/in.h>


struct termios all_oldterm;
char prot='>';
char end='\n';

void cmdline_stdin_new()
{
	struct termios oldterm, term;

	tcgetattr(0, &oldterm);
	memcpy(&term, &oldterm, sizeof(term));
	term.c_lflag &= ~(ICANON | ECHO | ISIG);
	tcsetattr(0, TCSANOW, &term);
	setbuf(stdin, NULL);

	memcpy(&all_oldterm, &oldterm, sizeof(term));

	return;
}

void
cmdline_interact()
{
	char c;
	int newline = 1;

	c = -1;
	while (1) {
		if (newline)
		{
			if (write(1, &prot, 1) < 0)
				break;
			newline = 0;
		}
		if (read(0, &c, 1) <= 0)
			break;
		if (write(1, &c, 1) < 0)
			break;
		if (c == end)
			newline = 1;
	}
}

void cmdline_stdin_exit()
{
	tcsetattr(fileno(stdin), TCSANOW, &all_oldterm);
}


int main()
{
	cmdline_stdin_new();
	cmdline_interact();
	cmdline_stdin_exit();	
	return 0;
}
