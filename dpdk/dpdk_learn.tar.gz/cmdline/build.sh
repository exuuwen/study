gcc -o main main.c cmdline.c cmdline_cirbuf.c cmdline_parse.c cmdline_rdline.c cmdline_vt100.c cmdline_socket.c cmdline_parse_string.c cmdline_parse_num.c
