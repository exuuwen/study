#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#define __USE_GNU
#include <pthread.h>

#include "spinlock.h"

//gcc -O2 -o test test_spinlock.c -I ../../include/ -lpthread
static uint64_t  wx;
static int cores;
static pthread_t ids[8];
static spinlock_t lock;

void test(int num)
{
	int i = 0;
	while(i < 10000000)
	{
		spinlock_lock(&lock);	
		i++;
		//printf("thread num %d\n", num);
		wx += num;
		spinlock_unlock(&lock);	
	}                        
    
	printf("A last value in %d thread %ld\n",  num, wx);
}

void * Run(void * para)
{
	int num = *((int*)para);
	int cpu;
	cpu_set_t mask;
	
	cpu = num % cores;
	CPU_ZERO(&mask);
        CPU_SET(cpu, &mask);
        assert(pthread_setaffinity_np(ids[num], sizeof(cpu_set_t), &mask) == 0);

	test(num + 1);
}

int main(int argc, char *argv[])
{
	int ret = 0;
	int num, i;
	int thread_num[8];
	
	if (argc < 2)
	{
		printf("usage: ./test thread_num[1~8]\n");
		return 0;
	}
	
	cores = sysconf(_SC_NPROCESSORS_CONF);
	assert(cores >= 0);

	num = atoi(argv[1]);
	if (num <= 0 || num > 8)
	{
		printf("invalid num\n");
		return 0;
	}

	spinlock_init(&lock);
	
	for (i=0; i<num; i++)
	{	
		thread_num[i] = i;
		ret = pthread_create(ids + i, NULL, Run, thread_num + i);
		assert(ret == 0);
	}
	

	for (i=0; i<num; i++)
	{	
  		pthread_join(ids[i], NULL);
	}
 
	printf("the last value in main %ld\n", wx);
	return 0;
}
