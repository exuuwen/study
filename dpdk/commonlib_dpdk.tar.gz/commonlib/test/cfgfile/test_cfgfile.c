#include <stdio.h>
#include <assert.h>

#include "cfgfile.h"

//gcc -o test test_cfgfile.c ../../src/cfgfile.c  -I ../../include/
int main(int argc, char* argv[])
{
	struct cfgfile *file;
	char *file_name = "test.cfg";
	unsigned int n_cores;

	file = cfgfile_load(file_name, 0);
	assert(file != NULL);

	n_cores = (unsigned int) cfgfile_num_sections(file, "core", strnlen("core", 5));
	printf("n_cores:%u\n", n_cores);

	if (cfgfile_has_section(file, "wx"))
	{
		printf("has section 'wx'\n");

		if (cfgfile_has_entry(file, "wx", "age"))
		{
			printf("section 'wx' has entry 'age'\n");
			printf("wx age is %s\n", cfgfile_get_entry(file, "wx", "age"));
		}
	}	

	return 0;
	
}
