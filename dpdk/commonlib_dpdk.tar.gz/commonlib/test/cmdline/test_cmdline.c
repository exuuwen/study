#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <inttypes.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <netinet/in.h>

#include "cmdline.h"
#include "cmdline_parse_string.h"
#include "cmdline_parse_num.h"


/* *** QUIT *** */
struct cmd_quit_result {
	cmdline_fixed_string_t quit;
};

static void cmd_quit_parsed(__attribute__((unused)) void *parsed_result,
		struct cmdline *cl,
		__attribute__((unused)) void *data)
{
	cmdline_quit(cl);
}

cmdline_parse_token_string_t cmd_quit_quit =
		TOKEN_STRING_INITIALIZER(struct cmd_quit_result, quit, "quit");

cmdline_parse_inst_t cmd_quit = {
	.f = cmd_quit_parsed,
	.data = NULL,
	.help_str = "Exit application",
	.tokens = {
		(void *)&cmd_quit_quit,
		NULL,
	},
};

/* *** help *** */
struct cmd_help_result {
        cmdline_fixed_string_t help;
};

static void cmd_help_parsed(__attribute__((unused)) void *parsed_result,
                struct cmdline *cl,
                __attribute__((unused)) void *data)
{       
	printf("hello world\n");	
}
        
cmdline_parse_token_string_t cmd_help =
                TOKEN_STRING_INITIALIZER(struct cmd_help_result, help, "help");

cmdline_parse_inst_t cmd_help_help = {
        .f = cmd_help_parsed,
        .data = NULL,
        .help_str = "Help application",
        .tokens = {
                (void *)&cmd_help,
                NULL,
        },
};

/***** show ****/
struct cmd_show_result {
        cmdline_fixed_string_t show;
	uint16_t num;
};

static void cmd_show_num_parsed(__attribute__((unused)) void *parsed_result,
                struct cmdline *cl,
                __attribute__((unused)) void *data)
{
	struct cmd_show_result *res = parsed_result;
       
	printf("show num:%u\n", res->num);	
}

cmdline_parse_token_string_t cmd_show_num_string =
                TOKEN_STRING_INITIALIZER(struct cmd_show_result, show, "show");

cmdline_parse_token_num_t cmd_show_num_num =
	TOKEN_NUM_INITIALIZER(struct cmd_show_result, num, UINT16);

cmdline_parse_inst_t cmd_show_num = {
	.f = cmd_show_num_parsed,
	.data = NULL,
	.help_str = "show num",
	.tokens = {
		(void *)&cmd_show_num_string,
		(void *)&cmd_show_num_num,
		NULL,
	},
};


/* List of commands */
cmdline_parse_ctx_t main_ctx[] = {
	(cmdline_parse_inst_t *)&cmd_quit,
	(cmdline_parse_inst_t *)&cmd_help_help,
	(cmdline_parse_inst_t *)&cmd_show_num,
	NULL,
};

int main()
{
	struct cmdline *cl;

	cl = cmdline_stdin_new(main_ctx, "test> ");
	if (cl == NULL)
		return;
	cmdline_interact(cl);
	cmdline_stdin_exit(cl);

	return 0;
}
