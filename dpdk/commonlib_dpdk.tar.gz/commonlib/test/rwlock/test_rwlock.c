#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#define __USE_GNU
#include <pthread.h>

#include "rwlock.h"

//gcc -O2 -o test test_rwlock.c -I ../../include/ -lpthread
static uint64_t  count;
static int cores;
static pthread_t ids[4];
static rwlock_t lock;

void *Run1(void *arg)
{
	int i;

        for(i=0; i<10; i++)
        {
                        rwlock_read_lock(&lock);
                        printf("thread 1 time %d, data %ld\n", i, count);
                        rwlock_read_unlock(&lock);
                        sleep(2);
        }
        return((void *)1);
}

void *Run2(void *arg)
{
	int i;

        sleep(1);
        for(i=0; i<10; i++)
        {
                        rwlock_read_lock(&lock);
                        printf("thread 2 time %d, data %ld\n", i, count);
                        rwlock_read_unlock(&lock);
                        sleep(5);
        }
        return((void *)2);
}

void *Run3(void *arg)
{
	int i;

        for(i=0; i<10; i++)
        {
                        rwlock_write_lock(&lock);
                        printf("thread 3 write lock time %d\n", i);
                        count ++;
                        rwlock_write_unlock(&lock);
                        sleep(2);
        }
        return((void *)3);
}

void *Run4(void *arg)
{
	int i;

        for(i=0; i<10; i++)
        {
                        rwlock_write_lock(&lock);
                        printf("thread 4 write lock time %d\n", i);
                        count ++;
                        rwlock_write_unlock(&lock);
                        sleep(2);
        }
        return((void *)4);
}


int main(int argc, char *argv[])
{
	int ret = 0;
	int i;

	rwlock_init(&lock);
	
	ret = pthread_create(&ids[0], NULL, Run1, NULL);
	assert(ret == 0);
	ret = pthread_create(&ids[1], NULL, Run2, NULL);
	assert(ret == 0);
	ret = pthread_create(&ids[2], NULL, Run3, NULL);
	assert(ret == 0);
	ret = pthread_create(&ids[3], NULL, Run4, NULL);
	assert(ret == 0);
	

	for (i=0; i<4; i++)
	{	
  		pthread_join(ids[i], NULL);
	}
 
	printf("the last value in main %ld\n", count);
	return 0;
}
