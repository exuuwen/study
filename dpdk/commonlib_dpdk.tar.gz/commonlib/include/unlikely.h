#ifndef _UNLIKELY_H_H_
#define _UNLIKELY_H_H_
/**
 * Check if a branch is likely to be taken.
 *
 * This gcc builtin allows the developer to indicate if a branch is
 * likely to be taken. Example:
 *
 *   if (likely(x > 1))
 *      do_stuff();
 *
 */
#define likely(x)  __builtin_expect((x),1)

/**
 * Check if a branch is unlikely to be taken.
 *
 * This gcc builtin allows the developer to indicate if a branch is
 * unlikely to be taken. Example:
 *
 *   if (unlikely(x < 1))
 *      do_stuff();
 *
 */
#define unlikely(x)  __builtin_expect((x),0)


#endif /* _UNLIKELY_H_H_ */
