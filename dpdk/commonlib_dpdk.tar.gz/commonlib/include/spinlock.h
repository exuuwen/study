#ifndef _SPINLOCK_H_H_
#define _SPINLOCK_H_H_

#include <sys/types.h>

/**
 * @file
 *
 * Spinlocks
 *
 * This file defines an API for read-write locks, which are implemented
 * in an architecture-specific way. This kind of lock simply waits in
 * a loop repeatedly checking until the lock becomes available.
 *
 * All locks must be initialised before use, and only initialised once.
 *
 */
/**
 * The spinlock_t type.
 */
typedef struct {
	volatile int locked; /**< lock status 0 = unlocked, 1 = locked */
} spinlock_t;

/**
 * A static spinlock initializer.
 */
#define SPINLOCK_INITIALIZER { 0 }

/**
 * Initialize the spinlock to an unlocked state.
 *
 * @param sl
 *   A pointer to the spinlock.
 */
static inline void
spinlock_init(spinlock_t *sl)
{
	sl->locked = 0;
}

/**
 * Take the spinlock.
 *
 * @param sl
 *   A pointer to the spinlock.
 */
static inline void
spinlock_lock(spinlock_t *sl)
{
	while (__sync_lock_test_and_set(&sl->locked, 1))
		while(sl->locked);
}

/**
 * Release the spinlock.
 *
 * @param sl
 *   A pointer to the spinlock.
 */
static inline void
spinlock_unlock (spinlock_t *sl)
{
	__sync_lock_release(&sl->locked);
}

/**
 * Try to take the lock.
 *
 * @param sl
 *   A pointer to the spinlock.
 * @return
 *   1 if the lock is successfully taken; 0 otherwise.
 */
static inline int
spinlock_trylock (spinlock_t *sl)
{
	return (__sync_lock_test_and_set(&sl->locked,1) == 0);
}

/**
 * Test if the lock is taken.
 *
 * @param sl
 *   A pointer to the spinlock.
 * @return
 *   1 if the lock is currently taken; 0 otherwise.
 */
static inline int spinlock_is_locked (spinlock_t *sl)
{
	return sl->locked;
}

/**
 * The spinlock_recursive_t type.
 */
typedef struct {
	spinlock_t sl; /**< the actual spinlock */
	volatile pid_t user; /**< core id using lock, -1 for unused */
	volatile int count; /**< count of time this lock has been called */
} spinlock_recursive_t;

/**
 * A static recursive spinlock initializer.
 */
#define SPINLOCK_RECURSIVE_INITIALIZER {SPINLOCK_INITIALIZER, -1, 0}

/**
 * Initialize the recursive spinlock to an unlocked state.
 *
 * @param slr
 *   A pointer to the recursive spinlock.
 */
static inline void spinlock_recursive_init(spinlock_recursive_t *slr)
{
	spinlock_init(&slr->sl);
	slr->user = -1;
	slr->count = 0;
}

/**
 * Take the recursive spinlock.
 *
 * @param slr
 *   A pointer to the recursive spinlock.
 */
static inline void spinlock_recursive_lock(spinlock_recursive_t *slr)
{
	int id = gettid();

	if (slr->user != id) {
		spinlock_lock(&slr->sl);
		slr->user = id;
	}
	slr->count++;
}
/**
 * Release the recursive spinlock.
 *
 * @param slr
 *   A pointer to the recursive spinlock.
 */
static inline void spinlock_recursive_unlock(spinlock_recursive_t *slr)
{
	if (--(slr->count) == 0) {
		slr->user = -1;
		spinlock_unlock(&slr->sl);
	}

}

/**
 * Try to take the recursive lock.
 *
 * @param slr
 *   A pointer to the recursive spinlock.
 * @return
 *   1 if the lock is successfully taken; 0 otherwise.
 */
static inline int spinlock_recursive_trylock(spinlock_recursive_t *slr)
{
	int id = gettid();

	if (slr->user != id) {
		if (spinlock_trylock(&slr->sl) == 0)
			return 0;
		slr->user = id;
	}
	slr->count++;
	return 1;
}

#endif /* _SPINLOCK_H_H_ */

