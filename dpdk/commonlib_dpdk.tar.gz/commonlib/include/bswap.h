#ifndef _BYTEORDER_H_H_
#define _BYTEORDER_H_H_

#include <stdint.h>

#include "constant_bswap.h"

#define bswap16(x) (uint16_t)(__builtin_constant_p(x) ?		\
				   constant_bswap16(x) :		\
				   __builtin_bswap16(x))

#define bswap32(x) (uint32_t)(__builtin_constant_p(x) ?		\
				   constant_bswap32(x) :		\
				   __builtin_bswap32(x))

#define bswap64(x) (uint64_t)(__builtin_constant_p(x) ?		\
				   constant_bswap64(x) :		\
				   __builtin_bswap64(x))

#endif
