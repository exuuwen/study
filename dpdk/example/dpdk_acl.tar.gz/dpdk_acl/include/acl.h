#ifndef _ACL_H_
#define _ACL_H_

#include <unistd.h>

#define DEFAULT_MAX_CATEGORIES  1
#define ACL_DENY_SIGNATURE	0xf0000000

struct acl_search_t {
	const uint8_t *data[MAX_PKT_BURST];
	struct rte_mbuf *m[MAX_PKT_BURST];
	uint32_t res[MAX_PKT_BURST];
	int num;
};


#endif
