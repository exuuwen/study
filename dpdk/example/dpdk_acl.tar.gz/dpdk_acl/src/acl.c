#include <rte_cycles.h>
#include <rte_debug.h>
#include <rte_malloc.h>
#include <rte_hash.h>
#include <rte_jhash.h>
#include <rte_acl.h>

#include "main.h"
#include "acl.h"

enum {
	PROTO_FIELD_IPV4,
	SRC_FIELD_IPV4,
	DST_FIELD_IPV4,
	SRCP_FIELD_IPV4,
	DSTP_FIELD_IPV4,
	NUM_FIELDS_IPV4
};

enum {
	CB_FLD_SRC_ADDR,
	CB_FLD_DST_ADDR,
	CB_FLD_SRC_PORT_LOW,
	CB_FLD_SRC_PORT_DLM,
	CB_FLD_SRC_PORT_HIGH,
	CB_FLD_DST_PORT_LOW,
	CB_FLD_DST_PORT_DLM,
	CB_FLD_DST_PORT_HIGH,
	CB_FLD_PROTO,
	CB_FLD_USERDATA,
	CB_FLD_NUM,
};


struct rte_acl_field_def ipv4_defs[NUM_FIELDS_IPV4] = {
	{
		.type = RTE_ACL_FIELD_TYPE_BITMASK,
		.size = sizeof(uint8_t),
		.field_index = PROTO_FIELD_IPV4,
		.input_index = RTE_ACL_IPV4VLAN_PROTO,
		.offset = 0,
	},
	{
		.type = RTE_ACL_FIELD_TYPE_MASK,
		.size = sizeof(uint32_t),
		.field_index = SRC_FIELD_IPV4,
		.input_index = RTE_ACL_IPV4VLAN_SRC,
		.offset = offsetof(struct ipv4_hdr, src_addr) -
			offsetof(struct ipv4_hdr, next_proto_id),
	},
	{
		.type = RTE_ACL_FIELD_TYPE_MASK,
		.size = sizeof(uint32_t),
		.field_index = DST_FIELD_IPV4,
		.input_index = RTE_ACL_IPV4VLAN_DST,
		.offset = offsetof(struct ipv4_hdr, dst_addr) -
			offsetof(struct ipv4_hdr, next_proto_id),
	},
	{
		.type = RTE_ACL_FIELD_TYPE_RANGE,
		.size = sizeof(uint16_t),
		.field_index = SRCP_FIELD_IPV4,
		.input_index = RTE_ACL_IPV4VLAN_PORTS,
		.offset = sizeof(struct ipv4_hdr) -
			offsetof(struct ipv4_hdr, next_proto_id),
	},
	{
		.type = RTE_ACL_FIELD_TYPE_RANGE,
		.size = sizeof(uint16_t),
		.field_index = DSTP_FIELD_IPV4,
		.input_index = RTE_ACL_IPV4VLAN_PORTS,
		.offset = sizeof(struct ipv4_hdr) -
			offsetof(struct ipv4_hdr, next_proto_id) +
			sizeof(uint16_t),
	},
};

RTE_ACL_RULE_DEF(acl4_rule, RTE_DIM(ipv4_defs));
#define MAX_ACL_RULE_NUM	100000

static struct rte_acl_ctx*
udpi_setup_acl(struct rte_acl_rule *acl_base, unsigned int acl_num, unsigned int lcore_id)
{
	char name[PATH_MAX];
	struct rte_acl_param acl_param;
	struct rte_acl_config acl_build_param;
	struct rte_acl_ctx *context;
	int dim = RTE_DIM(ipv4_defs);

	int socketid = rte_lcore_to_socket_id(lcore_id);

	/* Create ACL contexts */
	snprintf(name, sizeof(name), "%s%d", "dpdk acl", lcore_id);

	acl_param.name = name;
	acl_param.socket_id = socketid;
	acl_param.rule_size = RTE_ACL_RULE_SZ(dim);
	acl_param.max_rule_num = MAX_ACL_RULE_NUM;

	if ((context = rte_acl_create(&acl_param)) == NULL)
		rte_exit(EXIT_FAILURE, "Failed to create ACL context\n");

	if (rte_acl_set_ctx_classify(context, RTE_ACL_CLASSIFY_SSE) != 0)
		rte_exit(EXIT_FAILURE,
			"Failed to setup classify method for  ACL context\n");

	if (rte_acl_add_rules(context, acl_base, acl_num) < 0)
			rte_exit(EXIT_FAILURE, "add rules failed\n");

	/* Perform builds */
	memset(&acl_build_param, 0, sizeof(acl_build_param));

	acl_build_param.num_categories = DEFAULT_MAX_CATEGORIES;
	acl_build_param.num_fields = dim;
	memcpy(&acl_build_param.defs, ipv4_defs, sizeof(ipv4_defs));

	if (rte_acl_build(context, &acl_build_param) != 0)
		rte_exit(EXIT_FAILURE, "Failed to build ACL trie\n");

	rte_acl_dump(context);

	return context;
}

struct acl_flows
{
	uint32_t src_ip;	
	uint32_t dst_ip;	
	uint8_t src_mask;
	uint8_t dst_mask;
	uint16_t src_port;
	uint16_t src_port_h;
	uint16_t dst_port;
	uint16_t dst_port_h;
	uint8_t proto;
	uint8_t proto_mask;
};

struct acl_flows flows[2] =
{
	{IPv4(12, 12, 1, 52), IPv4(12, 12, 1, 0), 32, 24, 0, 65535, 2152, 2152, 17, 0xff},
};


void udpi_init_acl(void)
{
	unsigned lcore_id;
	unsigned int i;
	struct rte_acl_rule *acl_rules;
	uint8_t *rules;
	unsigned int acl_num = 1;

	/* Load  rules from the input file */
	rules = calloc(acl_num, sizeof(struct acl4_rule));
	
	for (i=0; i<acl_num; i++)
	{
		struct rte_acl_rule *next;
		next = (struct rte_acl_rule *)(rules + i * sizeof(struct acl4_rule));
		next->field[SRC_FIELD_IPV4].value.u32 = flows[i].src_ip; 
		next->field[SRC_FIELD_IPV4].mask_range.u32 = flows[i].src_mask; 
		next->field[DST_FIELD_IPV4].value.u32 = flows[i].dst_ip; 
		next->field[DST_FIELD_IPV4].mask_range.u32 = flows[i].dst_mask; 
		next->field[SRCP_FIELD_IPV4].value.u16 = flows[i].src_port;
		next->field[SRCP_FIELD_IPV4].mask_range.u16 = flows[i].src_port_h;
		next->field[DSTP_FIELD_IPV4].value.u16 = flows[i].dst_port;
		next->field[DSTP_FIELD_IPV4].mask_range.u16 = flows[i].dst_port_h;
		next->field[PROTO_FIELD_IPV4].value.u8 = flows[i].proto;
		next->field[PROTO_FIELD_IPV4].mask_range.u8= flows[i].proto_mask;
		next->data.userdata = ACL_DENY_SIGNATURE + i;
		next->data.priority = RTE_ACL_MAX_PRIORITY - i;
		next->data.category_mask = -1;
	}

	acl_rules = (struct rte_acl_rule *)rules;


	printf("IPv4 ACL entries %u:\n", acl_num);
	//dump_ipv4_rules((struct acl4_rule *)acl_rules, acl_num, 1);

	for (lcore_id = 0; lcore_id < RTE_MAX_LCORE; lcore_id++) 
	{
		if (rte_lcore_is_enabled(lcore_id) == 0)
				continue;

		struct udpi_core_params *core_params = udpi_get_core_params(lcore_id);
		
		if (core_params && (core_params->core_type == UDPI_CORE_IPV4_RX))
		{
			core_params->acx = udpi_setup_acl(acl_rules, acl_num, lcore_id);
		}
	}
	
}
