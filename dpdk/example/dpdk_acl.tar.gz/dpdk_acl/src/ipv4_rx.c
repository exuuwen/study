/*-
 *
 * Copyright(c) UCloud. All rights reserved.
 * All rights reserved.
 *
 */

#include <rte_malloc.h>
#include <rte_lcore.h>
#include <rte_port.h>
#include <rte_cycles.h>
#include <rte_byteorder.h>
#include <rte_ether.h>
#include <rte_tcp.h>
#include <rte_udp.h>
#include <rte_jhash.h>
#include <rte_acl.h>

#include <unistd.h>

#include "main.h"
#include "acl.h"

#define OFF_ETHHEAD	(sizeof(struct ether_hdr))
#define OFF_IPV42PROTO (offsetof(struct ipv4_hdr, next_proto_id))
#define MBUF_IPV4_2PROTO(m)	\
	(rte_pktmbuf_mtod((m), uint8_t *) + OFF_ETHHEAD + OFF_IPV42PROTO)
#define PREFETCH_OFFSET 3

static inline void process_packet(struct rte_mbuf *m, uint32_t res, uint32_t queue_id)
{
	if ((res & ACL_DENY_SIGNATURE) != 0)
	{
		return;
	}
	
	uint8_t *m_data = rte_pktmbuf_mtod(m, uint8_t *);
	struct udpi_pkt_metadata *c =
		(struct udpi_pkt_metadata *) RTE_MBUF_METADATA_UINT8_PTR(m, 0);

	struct ether_hdr *ether_hdr = (struct ether_hdr *)m_data;

	if (ether_hdr->ether_type != rte_cpu_to_be_16(ETHER_TYPE_IPv4))
	{
		return;
	}

	struct ipv4_hdr *ip_hdr =
		(struct ipv4_hdr *) &m_data[sizeof(struct ether_hdr)];

	/* TTL and Header Checksum are set to 0 */
	c->ip_src = rte_be_to_cpu_32(ip_hdr->src_addr);
	c->ip_dst = rte_be_to_cpu_32(ip_hdr->dst_addr);
	c->proto = ip_hdr->next_proto_id;

	uint8_t hlen = (ip_hdr->version_ihl & 0xf) * 4;

	if (c->proto == IPPROTO_UDP)
	{
		struct udp_hdr *uhr = (struct udp_hdr *)&m_data[sizeof(struct ether_hdr) + hlen];
		c->port_src = rte_be_to_cpu_16(uhr->src_port);
		c->port_dst = rte_be_to_cpu_16(uhr->dst_port);

		printf("udp ip_src 0x%x, ip_dst 0x%x, port_src %d, port_dst %d on queue %u, res %u\n", c->ip_src, c->ip_dst, c->port_src, c->port_dst, queue_id, res);
	}
	else if (c->proto == IPPROTO_TCP)
	{
		struct tcp_hdr *thr = (struct tcp_hdr *)&m_data[sizeof(struct ether_hdr) + hlen];
		c->port_src = rte_be_to_cpu_16(thr->src_port);
		c->port_dst = rte_be_to_cpu_16(thr->dst_port);
		printf("tcp ip_src 0x%x, ip_dst 0x%x, port_src %d, port_dst %d on queue %u, res %u\n", c->ip_src, c->ip_dst, c->port_src, c->port_dst, queue_id, res);
	}
	else
	{
		printf("proto %d ip_src 0x%x, ip_dst 0x%x on queue %u, res %u\n", c->proto, c->ip_src, c->ip_dst, queue_id, res);
	}

	c->tsc = rte_get_timer_cycles();
	
	rte_pktmbuf_free(m);

	return;
}

static inline void
udpi_prepare_one(struct rte_mbuf **pkts_in, struct acl_search_t *acl,
	int index)
{
	struct rte_mbuf *pkt = pkts_in[index];

	if (pkt->ol_flags & PKT_RX_IPV4_HDR) {

		/* Fill acl structure */
		acl->data[acl->num] = MBUF_IPV4_2PROTO(pkt);
		acl->m[(acl->num)++] = pkt;

	} else {
		/* Unknown type, drop the packet */
		rte_pktmbuf_free(pkt);
	}
}

static inline void
process_packets(struct rte_mbuf **m, uint32_t *res, int num, uint32_t queue)
{
	int i;

	/* Prefetch first packets */
	for (i = 0; i < PREFETCH_OFFSET && i < num; i++) {
		rte_prefetch0(rte_pktmbuf_mtod(
				m[i], void *));
	}

	for (i = 0; i < (num - PREFETCH_OFFSET); i++) {
		rte_prefetch0(rte_pktmbuf_mtod(m[
				i + PREFETCH_OFFSET], void *));
		process_packet(m[i], res[i], queue);
	}

	/* Process left packets */
	for (; i < num; i++)
		process_packet(m[i], res[i], queue);
}


void udpi_main_loop_ipv4_rx(void)
{
	uint32_t core_id = rte_lcore_id();
	
	struct udpi_core_params *core_params 
		= udpi_get_core_params(core_id);

	if((!core_params) 
		|| (core_params->core_type != UDPI_CORE_IPV4_RX))
	{
		rte_panic("Core %u misconfiguration\n", core_id);
		return;
	}

	RTE_LOG(INFO, USER1, 
		"Core %u is doing RX for port %u id %u\n", core_id, core_params->port_id, core_params->id);

	if (core_params->port_id >= udpi.n_ports)
	{
		rte_panic("Core %u misconfiguration port_id %u\n", core_id, core_params->port_id);
		return;
	}

	enum udpi_port_type port_type = udpi.ports[core_params->port_id].port_type;
	if (port_type == UDPI_PORT_NONE)
	{
		rte_panic("port %u misconfiguration port_type %u\n", core_params->port_id, port_type);
		return;
	}

	struct rte_acl_ctx *acx = core_params->acx;
	if (acx == NULL)
	{
		rte_panic("port %u misconfiguration acx\n", core_params->port_id);
		return;
	}

	struct rte_mbuf *pkts[udpi.bsz_hwq_rd];
	int n_mbufs = 0;
	
	uint64_t start_cycles = 0, cur_cycles = 0;
	uint64_t start_handle_cycles = 0, total_handle_cycles = 0;

	start_cycles = rte_get_timer_cycles();	

	while (1)
	{
		start_handle_cycles = rte_get_timer_cycles();	
		n_mbufs = rte_eth_rx_burst(core_params->port_id, core_params->id, pkts, udpi.bsz_hwq_rd);
		if(n_mbufs < 1)
		{
			continue;
		}

		int i = 0;
		struct acl_search_t acl_search;
		acl_search.num = 0;
		for (i = 0; i < PREFETCH_OFFSET && i < n_mbufs; i++) {
			rte_prefetch0(rte_pktmbuf_mtod(pkts[i], void *));
			rte_prefetch0(&pkts[i]->cacheline1);
		}	

		for (i = 0; i < (n_mbufs - PREFETCH_OFFSET); i++) {
			rte_prefetch0(rte_pktmbuf_mtod(pkts[i + PREFETCH_OFFSET], void *));
			rte_prefetch0(&pkts[i + PREFETCH_OFFSET]->cacheline1);
			udpi_prepare_one(pkts, &acl_search, i);
		}
		
		for (; i < n_mbufs; i++) {
			udpi_prepare_one(pkts, &acl_search, i);
		}

		if (acl_search.num) 
		{
			rte_acl_classify(
					acx,
					acl_search.data,
					acl_search.res,
					acl_search.num,
					DEFAULT_MAX_CATEGORIES);

			process_packets(acl_search.m, acl_search.res, acl_search.num, core_params->id);
		}

		cur_cycles = rte_get_timer_cycles();	
		total_handle_cycles += (cur_cycles - start_handle_cycles);

		core_params->core_handle_cycles = total_handle_cycles;
		core_params->core_total_cycles = cur_cycles - start_cycles;
	}
	
	return;
}

